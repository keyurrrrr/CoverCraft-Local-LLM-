"""Core logic for the Cover Letter Generator (PS42). No UI code here, so it can be tested on its own."""
import io
import json
import os
import re

from docx import Document
from docx.shared import Pt
from dotenv import load_dotenv
from pypdf import PdfReader

load_dotenv()

MODEL = "gemini-2.5-flash"
MIN_WORDS, MAX_WORDS = 220, 280          # target is ~250 words
MAX_INPUT_CHARS = 8000                   # keep prompts small and cheap

PROMPT_TEMPLATE = """You are an expert career coach who writes tailored cover letters for students and freshers.

Write a cover letter of about 250 words (strictly between {min_w} and {max_w} words).

STRICT RULES
1. Use ONLY facts that appear in the RESUME below (skills, projects, education, internships, numbers).
   Never invent employers, degrees, tools, achievements or numbers. If something is not in the resume, do not mention it.
2. Pick the 2-3 requirements from the JOB DESCRIPTION that best match the resume and show proof for each from the resume.
3. Tone: {tone}.
4. Structure: greeting, opening paragraph (role + company + one-line pitch), one body paragraph on matching skills/projects,
   one body paragraph on why this company, short closing with a call to action, sign-off with the candidate's name.
5. No placeholders such as [Your Name]. Output ONLY the letter text, no headings, no notes, no markdown.

CANDIDATE NAME: {name}
COMPANY: {company}
ROLE: {role}

JOB DESCRIPTION:
\"\"\"{jd}\"\"\"

RESUME:
\"\"\"{resume}\"\"\"
"""

RETRY_NOTE = (
    "\n\nYour previous draft had {n} words, which is outside {min_w}-{max_w}. "
    "Rewrite it so it is about 250 words. Keep every rule above."
)


def extract_pdf_text(file_like) -> str:
    """Extract text from an uploaded resume PDF (pypdf)."""
    reader = PdfReader(file_like)
    pages = [(p.extract_text() or "") for p in reader.pages]
    return clean_text("\n".join(pages))


def clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def word_count(text: str) -> int:
    return len(text.split())


def validate_inputs(resume: str, jd: str, company: str, name: str):
    """Return an error message string, or None if inputs are fine."""
    if len(resume.strip()) < 100:
        return "Resume text looks too short or empty (PDF may be a scanned image). Paste the text instead."
    if len(jd.strip()) < 50:
        return "Please paste a fuller job description (at least a few lines)."
    if not company.strip():
        return "Please enter the company name."
    if not name.strip():
        return "Please enter your name."
    return None


def build_prompt(resume, jd, company, role, tone, name) -> str:
    return PROMPT_TEMPLATE.format(
        min_w=MIN_WORDS, max_w=MAX_WORDS, tone=tone, name=name.strip(),
        company=company.strip(), role=role.strip() or "the advertised role",
        jd=jd.strip()[:MAX_INPUT_CHARS], resume=resume.strip()[:MAX_INPUT_CHARS],
    )


def call_llm(prompt: str) -> str:
    """Send the prompt to Gemini and return plain text. Key is read from GEMINI_API_KEY (.env)."""
    from google import genai

    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY not set. Copy .env.example to .env and add your key.")
    client = genai.Client(api_key=key)
    resp = client.models.generate_content(model=MODEL, contents=prompt)
    return (resp.text or "").strip()


def generate_cover_letter(resume, jd, company, role, tone, name, llm=call_llm) -> dict:
    """Build prompt -> call LLM -> check length -> retry once if outside range."""
    prompt = build_prompt(resume, jd, company, role, tone, name)
    letter = llm(prompt)
    retried = False
    n = word_count(letter)
    if not (MIN_WORDS <= n <= MAX_WORDS):
        retried = True
        letter = llm(prompt + RETRY_NOTE.format(n=n, min_w=MIN_WORDS, max_w=MAX_WORDS))
    letter = re.sub(r"^```\w*\n?|```$", "", letter.strip()).strip()   # strip stray code fences
    return {"letter": letter, "words": word_count(letter), "retried": retried}


def unsupported_numbers(letter: str, resume: str) -> list:
    """Simple hallucination check: numbers in the letter that never appear in the resume."""
    nums = set(re.findall(r"\d+(?:\.\d+)?", letter))
    return sorted(n for n in nums if n not in resume)


def make_docx(letter: str) -> bytes:
    """Return the letter as .docx bytes (python-docx)."""
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)
    for para in letter.split("\n\n"):
        doc.add_paragraph(para.strip())
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def load_samples(path="sample_inputs/samples.json"):
    with open(path, encoding="utf-8") as f:
        return json.load(f)
