"""PS42 - Cover Letter Generator (Streamlit UI).  Run:  streamlit run app.py"""
import streamlit as st

import letter_core as lc

st.set_page_config(page_title="Cover Letter Generator", page_icon="✉️", layout="wide")
st.title("✉️ Cover Letter Generator")
st.caption("Upload your resume, paste a job description and get a tailored ~250-word cover letter "
           "built only from facts in your resume.")

with st.sidebar:
    st.header("Options")
    tone = st.selectbox("Tone", ["Professional", "Enthusiastic", "Confident", "Formal"])
    use_sample = st.checkbox("Load a sample input")
    sample = None
    if use_sample:
        samples = lc.load_samples()
        label = st.selectbox("Sample", [s["id"] for s in samples])
        sample = next(s for s in samples if s["id"] == label)

col1, col2 = st.columns(2)
with col1:
    name = st.text_input("Your name", value=sample["name"] if sample else "")
    company = st.text_input("Company name", value=sample["company"] if sample else "")
    role = st.text_input("Role / position", value=sample["role"] if sample else "")
    pdf = st.file_uploader("Resume (PDF)", type=["pdf"])
    resume_text = ""
    if pdf is not None:
        try:
            resume_text = lc.extract_pdf_text(pdf)
        except Exception as e:
            st.error(f"Could not read the PDF: {e}")
    resume_text = st.text_area("Resume text (auto-filled from PDF, or paste here)",
                               value=resume_text or (sample["resume"] if sample else ""), height=260)
with col2:
    jd = st.text_area("Job description", value=sample["jd"] if sample else "", height=420)

if st.button("Generate cover letter", type="primary"):
    err = lc.validate_inputs(resume_text, jd, company, name)
    if err:
        st.warning(err)
    else:
        try:
            with st.spinner("Writing your letter..."):
                result = lc.generate_cover_letter(resume_text, jd, company, role, tone, name)
            st.session_state["result"] = result
            st.session_state["resume"] = resume_text
        except Exception as e:
            st.error(f"LLM call failed: {e}")

if "result" in st.session_state:
    r = st.session_state["result"]
    st.subheader("Your cover letter")
    edited = st.text_area("You can edit before downloading", value=r["letter"], height=380)
    st.caption(f"{lc.word_count(edited)} words" + (" • auto-regenerated once to fix length" if r["retried"] else ""))

    suspicious = lc.unsupported_numbers(edited, st.session_state["resume"])
    if suspicious:
        st.warning("These numbers are not in your resume - please verify: " + ", ".join(suspicious))

    c1, c2 = st.columns(2)
    c1.download_button("⬇️ Download .docx", lc.make_docx(edited), file_name="cover_letter.docx",
                       mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    c2.download_button("⬇️ Download .txt", edited, file_name="cover_letter.txt")
