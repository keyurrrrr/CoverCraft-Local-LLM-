# Cover Letter Generator (PS 42)

**Problem statement:** Writing a new cover letter for every job is tiring. This app generates a tailored ~250-word cover letter from a candidate's resume (PDF or text) and a job description, using only real resume details, and lets the user download it as `.docx`.

## Features
- Resume upload (PDF) or paste text; job description, company, role and tone inputs
- Prompt forces "use only facts from the resume" and a 220-280 word length
- Auto-retry once if the length is off; warning if the letter contains numbers not found in the resume
- Edit in the browser, then download as `.docx` or `.txt`
- 5 built-in sample inputs (`sample_inputs/samples.json`)

## Tech
Python, Streamlit, Gemini 2.5 Flash (`google-genai`), pypdf, python-docx.

## How to run
```bash
pip install -r requirements.txt
cp .env.example .env        # then put your free Gemini key in .env (https://aistudio.google.com/apikey)
streamlit run app.py
```
Run all samples from the terminal: `python test_samples.py` (outputs saved in `outputs/`).

## Files
| File | Purpose |
|---|---|
| `app.py` | Streamlit UI |
| `letter_core.py` | Prompt, LLM call, validation, length check, .docx export |
| `test_samples.py` | Runs the 5 sample inputs |
| `sample_inputs/samples.json` | Sample resumes + job descriptions |

## Screenshots
Add 1-2 screenshots here (e.g. `![demo](screenshots/demo.png)`).
