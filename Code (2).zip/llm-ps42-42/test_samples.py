"""Run all 5 sample inputs through the real LLM and save outputs (for the report + screenshots).
Usage:  python test_samples.py"""
import os
import letter_core as lc

os.makedirs("outputs", exist_ok=True)
for s in lc.load_samples():
    res = lc.generate_cover_letter(s["resume"], s["jd"], s["company"], s["role"], "Professional", s["name"])
    extra = lc.unsupported_numbers(res["letter"], s["resume"])
    with open(f"outputs/{s['id']}.txt", "w", encoding="utf-8") as f:
        f.write(res["letter"])
    print(f"{s['id']}: {res['words']} words | retried={res['retried']} | numbers not in resume={extra}")
